<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');
initializeDatabase();

$configuration = ProjectConfiguration::getApplicationConfiguration( 'fe', 'unittest', true);
$database_manager = new sfDatabaseManager($configuration);
Doctrine::loadData(sfConfig::get('sf_test_dir').'/fixtures/fixtures.yml');

$t = new lime_test(22, new lime_output_color());

$issue = Doctrine::getTable('Issue')->getIssueById(12);
$t->ok($issue instanceof Issue, '->getIssueById() returns the right object');
$t->ok($issue->getId() == 12, '->getIssueById() returns an object of with the right id');


$t->ok(Doctrine::getTable('Issue')->getQueryForMilstoneIssues(2, 2) instanceof Doctrine_Query, '->getQueryForMilstoneIssues(2, 2) returns a doctrine query object');
$t->is(Doctrine::getTable('Issue')->getQueryForMilstoneIssues(), null, '->getQueryForMilstoneIssues() returns null');

$t->ok(Doctrine::getTable('Issue')->getQueryForProjectIssues(2) instanceof Doctrine_Query, '->getQueryForProjectIssues(2) returns a doctrine query object');
$t->is(Doctrine::getTable('Issue')->getQueryForMilstoneIssues(), null, '->getQueryForProjectIssues() returns null');

$t->ok(Doctrine::getTable('Issue')->getQueryForUserIssues(2) instanceof Doctrine_Query, '->getQueryForUserIssues(2) returns a doctrine query object');
$t->is(Doctrine::getTable('Issue')->getQueryForUserIssues(), null, '->getQueryForUserIssues() returns null');

$logtimes = Doctrine::getTable('Issue')->retrieveLogTimeForProject(5);
$t->is($logtimes['project_log_times'], '15', '->retrieveLogTimeForProject(5) returns a doctrine query object');
$logtimes = Doctrine::getTable('Issue')->retrieveLogTimeForProject();
$t->is(Doctrine::getTable('Issue')->retrieveLogTimeForProject(), null, '->retrieveLogTimeForProject() returns null');

$results = Doctrine::getTable('Issue')->getIssueForProjectOrderedByStatusType(2);

$t->is(count($results), 6, 'getIssueForProjectOrderedByStatusType return the right numebr of results');
$t->is($results[0]->getStatus()->getStatusType(), 'invalid', 'getIssueForProjectOrderedByStatusType return the right numebr of results');
$t->is($results[1]->getStatus()->getStatusType(), 'new', 'getIssueForProjectOrderedByStatusType return the right numebr of results');

$result = Doctrine::getTable('Issue')->getSpentTimeOnIssuesClosedAndInvalidForProject(3);
$t->is($result['project_log_times'], null, 'getSpentTimeOnIssuesClosedAndInvalidForProject ok');
$result = Doctrine::getTable('Issue')->getOpenIssuesEstimatedTimeForProject(3);
$t->is($result['estimated_time'], 0, 'getOpenIssuesEstimatedTimeForProject ok');

$result = Doctrine::getTable('Issue')->getSpentTimeOnIssuesClosedAndInvalidForProject(5);
$t->is($result['project_log_times'], null, 'getSpentTimeOnIssuesClosedAndInvalidForProject ok');
$result = Doctrine::getTable('Issue')->getOpenIssuesEstimatedTimeForProject(5);
$t->is($result['estimated_time'], 136, 'getOpenIssuesEstimatedTimeForProject ok');

$result = Doctrine::getTable('Issue')->getSpentTimeOnIssuesClosedAndInvalidForProject(1);
$t->is($result['project_log_times'], 203, 'getSpentTimeOnIssuesClosedAndInvalidForProject ok');
$result = Doctrine::getTable('Issue')->getOpenIssuesEstimatedTimeForProject(1);
$t->is($result['estimated_time'], 126, 'getOpenIssuesEstimatedTimeForProject ok');

$results = Doctrine::getTable('Issue')->getClosedIssueForProject(2);
$t->is(count($results), 0, 'getClosedIssueForProject ok');

$results = Doctrine::getTable('Issue')->getNewIssueForProject(2);
$t->is(count($results), 5, 'getNewIssueForProject ok');

$results = Doctrine::getTable('Issue')->getInvalidIssueForProject(2);
$t->is(count($results), 1, 'getInvalidIssueForProject ok');
