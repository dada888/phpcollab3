<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');
initializeDatabase();

$configuration = ProjectConfiguration::getApplicationConfiguration( 'fe', 'unittest', true);
$database_manager = new sfDatabaseManager($configuration);
Doctrine::loadData(sfConfig::get('sf_test_dir').'/fixtures/fixtures.yml');

$t = new lime_test(8, new lime_output_color());

$issue = Doctrine::getTable('Issue')->getIssueById(12);
$t->ok($issue instanceof Issue, '->getIssueById() returns the right object');
$t->ok($issue->getId() == 12, '->getIssueById() returns an object of with the right id');


$t->ok(Doctrine::getTable('Issue')->getQueryForMilstoneIssues(2, 2) instanceof Doctrine_Query, '->getQueryForMilstoneIssues(2, 2) returns a doctrine query object');
$t->is(Doctrine::getTable('Issue')->getQueryForMilstoneIssues(), null, '->getQueryForMilstoneIssues() returns null');

$t->ok(Doctrine::getTable('Issue')->getQueryForProjectIssues(2) instanceof Doctrine_Query, '->getQueryForProjectIssues(2) returns a doctrine query object');
$t->is(Doctrine::getTable('Issue')->getQueryForMilstoneIssues(), null, '->getQueryForProjectIssues() returns null');

$t->ok(Doctrine::getTable('Issue')->getQueryForUserIssues(2) instanceof Doctrine_Query, '->getQueryForUserIssues(2) returns a doctrine query object');
$t->is(Doctrine::getTable('Issue')->getQueryForUserIssues(), null, '->getQueryForUserIssues() returns null');

