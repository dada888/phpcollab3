<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');
include(sfConfig::get('sf_plugins_dir').'/idProjectManagmentPlugin/lib/helper/idGanttShowHelper.php');

$t = new lime_test(13, new lime_output_color());

$t->is(isDateInBetweenByMonth('2009-01-01', '2008-12-31', '2009-01-31'), true, 'isDateInBetweenByMonth($date, $stating_date, $ending_date) ok');
$t->is(isDateInBetweenByMonth('2009-02-15', '2009-01-12', '2009-11-01'), true, 'isDateInBetweenByMonth($date, $stating_date, $ending_date) ok');
$t->is(isDateInBetweenByMonth('2009-01-05', '2009-02-12', '2009-11-01'), false, 'isDateInBetweenByMonth($date, $stating_date, $ending_date) ok');

$t->is(getLastDayOfMonth('2009', '02'), '28', 'getLastDayOfMonth($year, $month) ok');
$t->is(getLastDayOfMonth('2009', '01'), '31', 'getLastDayOfMonth($year, $month) ok');
$t->is(getLastDayOfMonth('2009', '06'), '30', 'getLastDayOfMonth($year, $month) ok');

$t->ok(isDateInBetweenByDay('2009-01-01', '2008-12-31', '2009-01-31'), 'isDateInBetweenByDay($date, $stating_date, $ending_date) ok');
$t->ok(isDateInBetweenByDay('2009-02-15', '2009-01-12', '2009-11-01'), 'isDateInBetweenByDay($date, $stating_date, $ending_date) ok');
$t->ok(!isDateInBetweenByDay('2009-01-05', '2009-01-12', '2009-11-01'), 'isDateInBetweenByDay($date, $stating_date, $ending_date) ok');


$t->is(getLatestDateOfMonth('2009', '01'), '2009/01/31', 'getLAtestDateOfMonth() ok');

$t->ok(isLastCategoryByMonth('2009/09/12', '2009/09/15'), 'isLastCategoryByMonth($date, $stating_date, $ending_date) ok');
$t->ok(isLastCategoryByMonth('2009/09/30', '2009/09/30'), 'isLastCategoryByMonth($date, $stating_date, $ending_date) ok');
$t->ok(!isLastCategoryByMonth('2009/09/31', '2009/10/01'), 'isLastCategoryByMonth($date, $stating_date, $ending_date) ok');
