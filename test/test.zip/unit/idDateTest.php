<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');
include(sfConfig::get('sf_plugins_dir').'/idUtilPlugin/lib/idDate.class.php');

$t = new lime_test(5, new lime_output_color());

//getStartingDate($project, $add_days_to_the_end = 0)
$result = idDate::getStartingDateForObject($object = null, $subtract_days = 0, $format = 'Y/m/d');
$result = idDate::getStartingDateForObject(null, 0, $format = 'Y/m/d');
$t->is($result, date('Y/m/d'), 'getStartingDateForObject() formats the date the right way');
$result = idDate::getStartingDateForObject(null, 0, $format = 'Y-m-d');
$t->is($result, date('Y-m-d'), 'getStartingDateForObject() formats the date the right way');
$result = idDate::getStartingDateForObject(null, 0, $format = 'd/m/Y');
$t->is($result, date('d/m/Y'), 'getStartingDateForObject() formats the date the right way');

$project = Doctrine::getTable('Project')->find(5);
$result = idDate::getStartingDate($project, 3, $format = 'Y/m/d');
$t->


//getDaysFromWorkingHours($hours, $working_hours_per_day = 8, $working_days_per_week = 5)
$result = idDate::getNumberOfDaysWithWeekendFromWorkingHours($hours, $working_hours_per_day = 8, $working_days_per_week = 5);

//getEndingDate($project_starting_date, $project_ending_date, $estimated_time_for_project, $add_days_to_the_end = 0)
$result = idDate::getFutureDate($starting_date, $estimated_time_for_project, $add_days_to_the_end = 0, $max_ending_date = null);

//getEstimatedEndingDate($project_starting_date, $estimated_time_for_project, $resources)

//retrieveWorkingIntervals($project_starting_date, $estimated_ending_date)
$result = idDate::getWeekWithoutWeekendsByStartDayAndEndDay($starting_date, $ending_date);

//retrieveProcessingDatePerResource($project_starting_date, $project_ending_date, $estimated_ending_date, $resources)

