<?php
include(dirname(__FILE__).'/../bootstrap/unit.php');
initializeDatabase();

$configuration = ProjectConfiguration::getApplicationConfiguration( 'fe', 'unittest', true);
new sfDatabaseManager($configuration);
Doctrine::loadData(sfConfig::get('sf_test_dir').'/fixtures/fixtures.yml');


$issue = Doctrine::getTable('Issue')->createQuery()->fetchOne();

$t = new lime_test(2, new lime_output_color());

$t->like("".$issue, '/#.* new issue/', '__toString() returns the right value');
$t->is($issue->hasComments(), true, 'hasComments() returns the right value');
