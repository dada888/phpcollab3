<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');
initializeDatabase();

$configuration = ProjectConfiguration::getApplicationConfiguration( 'fe', 'unittest', true);
$database_manager = new sfDatabaseManager($configuration);
Doctrine::loadData(sfConfig::get('sf_test_dir').'/fixtures/fixtures.yml');

$t = new lime_test(3, new lime_output_color());

$sql = "SELECT s.id AS s__id, s.name AS s__name, s.status_type AS s__status_type, s.position AS s__position FROM status s ORDER BY s.position";
$query = Doctrine::getTable('Status')->getStatusesOrderByPositionQuery();
$t->ok($query instanceof Doctrine_Query, '->getStatusesOrderByPositionQuery() returns the right object');
$t->is($query->getSql(), $sql, '->getStatusesOrderByPositionQuery() makes the right query');

$t->is(Doctrine::getTable('Status')->retrieveHighestPosition(), 1, '->retrieveHighestPosition() returns the rigth value');