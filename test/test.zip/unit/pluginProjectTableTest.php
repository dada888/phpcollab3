<?php

include(dirname(__FILE__).'/../bootstrap/unit.php');
initializeDatabase();

$configuration = ProjectConfiguration::getApplicationConfiguration( 'fe', 'unittest', true);
new sfDatabaseManager($configuration);
Doctrine::loadData(sfConfig::get('sf_test_dir').'/fixtures/fixtures.yml');

$t = new lime_test(6, new lime_output_color());

$t->ok(Doctrine::getTable('Project')->getProjectRelatedMilestonesAndIssues(1) instanceof Project, 'getProjectRelatedMilestonesAndIssues(1) returns a propject object');
$t->is(Doctrine::getTable('Project')->getProjectRelatedMilestonesAndIssues(1213782), null, 'getProjectRelatedMilestonesAndIssues(1213782) returns null if the project is not found');

$t->ok(Doctrine::getTable('Project')->getProjectMilestonesAndUsers(1) instanceof Project, 'getProjectMilestonesAndUsers(1) returns a propject object');
$t->is(Doctrine::getTable('Project')->getProjectMilestonesAndUsers(1213782), null, 'getProjectMilestonesAndUsers(1213782) returns null if the project is not found');

$projects = Doctrine::getTable('Project')->getQueryToRetrieveProjectWhereUserHaveAssignedIssues(3)->execute();

$t->is(count($projects), 1, 'getQueryToRetrieveProjectWhereUserHaveAssignTickets(user) returns one project');
$t->is($projects['0']['id'], 3, 'getQueryToRetrieveProjectWhereUserHaveAssignTickets(user) returns the right project');
