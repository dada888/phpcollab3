<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser->
  get('/')->

  click('Login', array('signin' => array('username' => 'customer', 'password' => 'customer')))->

  followRedirect()->

  with('request')->begin()->
    isParameter('module', 'idDashboard')->
    isParameter('action', 'index')->
  end()->

  with('response')->begin()->
    checkElement('.contentWrapper .dashboard h3:contains("Recent Activity")')->
    checkElement('.contentWrapper .dashboard .recent .menu span:contains("Today")')->
    checkElement('.contentWrapper .dashboard .recent .menu span:contains("Yesterday")')->
    checkElement('.contentWrapper .dashboard .recent .menu span:contains("September 20th")')->
    checkElement('.contentWrapper .dashboard .recent .menu .right span:contains("Project")')->
    

    checkElement('#sidebar-right')->
    checkElement('#sidebar-right h3:contains("Open Projects")')->
    checkElement('#sidebar-right .menuStatus .statusTitle a:contains("ABC Project")')->
    checkElement('#sidebar-right .menuStatus .statusTitle a:contains("ABC Project 2")')->
    checkElement('#sidebar-right h3:contains("Milestones")')->
    checkElement('#sidebar-right .milestone-red:contains("Late")')->
    checkElement('#sidebar-right .milestone-green:contains("Upcoming")')->
  end()
;