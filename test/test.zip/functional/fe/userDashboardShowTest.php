<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser->
  get('/')->

  click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->

  followRedirect()->

  with('request')->begin()->
    isParameter('module', 'idDashboard')->
    isParameter('action', 'index')->
  end()->

  with('response')->begin()->
    checkElement('div#my-issues table.table tr td:contains("#1")')->
    checkElement('div#my-issues table.table tr td:contains("new issue")')->
    checkElement('div#my-issues table.table tr td:contains("normal")')->

    checkElement('h2:contains("My issues")')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/1"]', '#1')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/2"]', '#2')->
    checkElement('div#my-issues table.table tr td:contains("Mario (user) Wage")')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/3"]', false)->

    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/edit/1"]', 'Edit')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/delete/1"]', 'Delete')->

    info('check project where I have assigned tickets')->
    checkElement('a[href="/index.php/en/idProject/show/3"]', '/terzo progetto/')->
    checkElement('a[href="/index.php/en/idProject/show/2"]', false)->
    checkElement('a[href="/index.php/en/idProject/show/4"]', false)->

  end()->

  click('Dashboard')->

  click('Logout')->
  followRedirect()->
  
  click('Login', array('signin' => array('username' => 'user', 'password' => 'user')))->

  followRedirect()->

  with('request')->begin()->
    isParameter('module', 'idDashboard')->
    isParameter('action', 'index')->
  end()->

  with('response')->begin()->
    checkElement('div#my-issues table.table tr td:contains("#1")')->
    checkElement('div#my-issues table.table tr td:contains("new issue")')->
    checkElement('div#my-issues table.table tr td:contains("normal")')->

    checkElement('h2:contains("My issues")')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/2"]', '#2')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/3"]', '#3')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/4"]', '#4')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/5"]', '#5')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/6"]', '#6')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/7"]', '#7')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/8"]', '#8')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/9"]', '#9')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/10"]', '#10')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/11"]', '#11')->
    checkElement('div#my-issues table.table tr td a[href="/index.php/en/idProject/3/idIssue/show/12"]', false)->

    checkElement('tr td span', '1')->
    checkElement('tr td a[href="/index.php/en/idDashboard?page=2"]', '2')->
  end()

;