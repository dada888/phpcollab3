<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();


$browser->

  get('/')->
  click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))->
  followRedirect()->

  click('All Projects')->

  click('Il mio primo progetto')->

  click('View all milestones')->

  with('request')->begin()->
    isParameter('module', 'idMilestone')->
    isParameter('action', 'index')->
  end()->

  with('response')->begin()->
    checkElement('table.table tr td:contains("first iteration")')->
    checkElement('table.table tr td:contains("first iteration for project 1")')->
    checkElement('table.table tr td:contains("second iteration")')->
    checkElement('table.table tr td:contains("second iteration for project one")')->
  end()

  ;
