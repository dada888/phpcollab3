<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser->
  get('/')->

  click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->

  followRedirect()->

  click('Projects')->

  click('Il mio terzo progetto')->

  with('request')->begin()->
    isParameter('module', 'idProject')->
    isParameter('action', 'show')->
    isParameter('id', '3')->
  end()->
  
  with('response')->begin()->
    checkElement('h2:contains("Project details")')->
    checkElement('h2:contains("Users of this project")')->
    checkElement('h2:contains("Milestones")')->

    checkElement('div#block-tables table.table tr td:contains("Il terzo progetto creato con il plugin idProjectManagmentPlugin")')->

    checkElement('div#users-table table.table tr td:contains("puser")')->
    checkElement('div#users-table table.table tr td:contains("user")')->

    checkElement('div#milestone-table table.table tr td:contains("third iteration for project 3")')->
    
  end();