<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->initializeDatabase();

$browser->

get('/en/idProject/show/5')->
click('Login', array('signin' => array('username' => 'user', 'password' => 'user')))->
  followRedirect()->
  with('response')->begin()->
    isStatusCode('404')->
  end()->

get('/')->

click('Logout')->

get('/en/idProject/show/3')->
click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->
  followRedirect()->
  with('request')->begin()->
    isParameter('module', 'idProject')->
    isParameter('action', 'show')->
  end()->

  with('response')->begin()->
    isStatusCode(200)->

    checkElement('th:contains("Id")')->
    checkElement('th:contains("Name")')->
    checkElement('th:contains("Description")')->
    checkElement('th:contains("Public")')->
    checkElement('th:contains("Starting date")')->
    checkElement('th:contains("Updated at")', false)->
    checkElement('th:contains("End date")')->

    checkElement('td:contains("Il mio terzo progetto")')->
    checkElement('td:contains("Il terzo progetto creato con il plugin idProjectManagementPlugin")')->
    checkElement('td:contains("Public")')->
    checkElement('td:contains("'.date("Y-m-d", strtotime("-3 day")).'")')->

    checkElement('div#users-table div.content div.inner table.table tr td a[href="/index.php/en/sfGuardUser/3/show"]', '3')->
    checkElement('div#users-table div.content div.inner table.table tr td a[href="/index.php/en/sfGuardUser/3/edit"]', false)->

    checkElement('div#block-tables div.secondary-navigation ul li a[href="/index.php/en/idProject/3/idIssue/new"]', 'Create issue')->
    checkElement('div#block-tables div.secondary-navigation ul li a[href="/index.php/en/idProject/3/idMilestone/new"]', 'Create milestone')->
    checkElement('div#block-tables div.secondary-navigation ul li a[href="/index.php/en/idProject/3/idIssues"]', 'View all issues')->
    checkElement('div#block-tables div.secondary-navigation ul li a[href="/index.php/en/idProject/3/idMilestone"]', 'View all milestones')->

  end()->

  click('Dashboard')->
  click('Logout')->
  followRedirect()->

  click('Login', array('signin' => array('username' => 'pmanager', 'password' => 'pmanager')))->
  followRedirect()->

  click('Projects')->
  click('Il mio primo progetto')->

  with('response')->begin()->
    checkElement('a[href~="idProject/1/show/Gantt"]', '/Gantt chart/')->
  end()->

  click('Dashboard')->

  click('Logout')->

  get('/en/idProject/show/5')->
  click('Login', array('signin' => array('username' => 'pmanager', 'password' => 'pmanager')))->
  followRedirect()->
  with('request')->begin()->
    isParameter('module', 'idProject')->
    isParameter('action', 'show')->
  end()->

  with('response')->begin()->
    isStatusCode(200)->

    checkElement('td.green','/Estimated time : 136.0 hours - Log time: 15.0 hours/')->

  end()->

  get('/en/idProject/show/1')->
  with('request')->begin()->
    isParameter('module', 'idProject')->
    isParameter('action', 'show')->
  end()->

  with('response')->begin()->
    isStatusCode(200)->

    checkElement('td.green','/Estimated time : 510.0 hours - Log time: 237.5 hours/')->

  end()

;