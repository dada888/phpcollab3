<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new repositoryTestFunctional(new sfBrowser());
$browser->readSvnFakeRepository();

$browser->
  get('/')->
  click('Login', array('signin' => array('username' => 'user', 'password' => 'user')))->
  followRedirect()->
  
  post('/en/idRepository/showall')->
 
  with('request')->begin()->
    isParameter('module', 'idRepository')->
    isParameter('action', 'showall')->
  end()->
 
  with('response')->begin()->
    isStatusCode(200)->
    checkElement('.block .content .table td a[href="/index.php/en/idRepository/showdetails/revisionid/154"]',1)->
    checkElement('.block .content .table td a[href="/index.php/en/idRepository/showdetails/revisionid/1"]',1)->

  end()
;