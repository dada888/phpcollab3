<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();


$browser->
  get('/')->
  click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))->
  followRedirect()->

  click('Priorities')->
  with('response')->begin()->
    checkElement('#block-tables table.table th:contains("Id")')->
    checkElement('#block-tables table.table th:contains("Name")')->
    checkElement('#block-tables table.table th:contains("Actions")')->
    checkElement('#block-tables table.table th:contains("Order priority list")')->

    checkElement('#block-tables table.table td', '1', array('position' => 2))->
    checkElement('#block-tables table.table td', '2', array('position' => 7))->
    checkElement('#block-tables table.table td', '3', array('position' => 12))->

    checkElement('#block-tables table.table td a[href="/index.php/en/idPriority/moveup/2"]', 'move up')->
    checkElement('#block-tables table.table td a[href="/index.php/en/idPriority/moveup/3"]', 'move up')->

    checkElement('#block-tables table.table td a[href="/index.php/en/idPriority/movedown/1"]', 'move down')->
    checkElement('#block-tables table.table td a[href="/index.php/en/idPriority/movedown/2"]', 'move down')->
  end()->

  click('move up', array(), array('position' => 10))->

  with('response')->begin()->
    checkElement('#block-tables table.table td', '2', array('position' => 2))->
    checkElement('#block-tables table.table td', '1', array('position' => 7))->
    checkElement('#block-tables table.table td', '3', array('position' => 12))->
  end()->

  click('move down', array(), array('position' => 10))->

  with('response')->begin()->
    checkElement('#block-tables table.table td', '2', array('position' => 2))->
    checkElement('#block-tables table.table td', '3', array('position' => 7))->
    checkElement('#block-tables table.table td', '1', array('position' => 12))->
  end()->

  click('move down', array(), array('position' => 5))->

  with('response')->begin()->
    checkElement('#block-tables table.table td', '3', array('position' => 2))->
    checkElement('#block-tables table.table td', '2', array('position' => 7))->
    checkElement('#block-tables table.table td', '1', array('position' => 12))->
  end()


;
