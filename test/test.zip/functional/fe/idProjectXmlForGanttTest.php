<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');
$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser
  ->get('/')
  ->click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))
  ->get('/Gantt/xmlAnalysisGanttData/5/2/data.xml')->

  with('request')->begin()->
    isParameter('module', 'idGantt')->
    isParameter('action', 'xmlAnalysisGanttData')->
    isParameter('project_id', '5')->
    isParameter('resources', '2')->
    isFormat('xml')->
  end()->

  with('response')->begin()->
    checkElement('chart[dateFormat="yyyy/mm/dd"]')->
    checkElement('categories[bgColor="333333"] category', 2)->
    checkElement('categories[bgColor="99cc00"] category', 37)->
    checkElement('processes[positionInGrid="right"] process', 2)->
    checkElement('tasks task', 6)->
    checkElement('trendlines line[displayValue="Start date"]')->
    checkElement('trendlines line[displayValue="Today"]')->
    checkElement('trendlines line[displayValue="Estimated end date"]')->
    checkElement('trendlines line[displayValue="End date"]')->
  end()

;

$browser->test()->fail('check http://phpcollab/fe_dev.php/Gantt/xmlProjectStatusGanttData/5/data.xml');

;
