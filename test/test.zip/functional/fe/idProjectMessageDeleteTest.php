<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();


$browser->

  get('/')->
  click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->
  followRedirect()->

  click('My Projects')->
  click('Il mio secondo progetto')->
  click('Messages')->

  with('response')->begin()->
    checkElement('table.table tr', 4)->
  end()->

  click('Delete')->

  followRedirect()->

  with('request')->begin()->
    isParameter('module', 'idMessage')->
    isParameter('action', 'index')->
  end()->

  with('response')->begin()->
    checkElement('table.table tr', 3)->
  end()
;