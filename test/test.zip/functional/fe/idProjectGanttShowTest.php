<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->initializeDatabase();

$browser->

  get('/en/idProject/show/5')->
  click('Login', array('signin' => array('username' => 'pmanager', 'password' => 'pmanager')))->
  followRedirect()->

  with('response')->begin()->
    checkElement('a[href~="idProject/5/show/Gantt"]', '/Gantt chart/')->
  end()->

  click('Gantt chart')->
  with('response')->begin()->
    checkElement('h2:contains("Analysis gantt chart")')->
    checkElement('form input[id="gantt_data_resources_number"][name="gantt_data[resources_number]"]')->
    checkElement('form input[type="submit"]')->
    checkElement('form[action~="idProject/5/analysisGanttChart"]')->
  end()->

  click('Show analysis gantt chart', array('gantt_data' => array('resources_number' => 5)))->

  with('request')->begin()->
    isParameter('module', 'idGantt')->
    isParameter('action', 'analysisGanttChartShow')->
    isParameter('project_id', '5')->
    isParameter('gantt_data[resources_number]', '5')->
  end()->

  with('response')->begin()->
    checkElement('h2:contains("Analysis gantt chart")')->
    checkElement('h3:contains("Legenda")')->
    checkElement('div:contains("This chart considers 10 out of 15 issues (5 with no estimated time)")')->
    checkElement('div:contains("Issue with estimated time:")')->
    checkElement('div:contains("3 issues with tracker user story")')->
    checkElement('div:contains("6 issues with tracker Task")')->
    checkElement('div:contains("1 issues with tracker empty")')->

    checkElement('div:contains("Issue with no estimated time:")')->
    checkElement('div:contains("5 issues with tracker Bug")')->

  end()->

  get('/en/idProject/show/1')->
  click('Gantt chart')->

  click('Show project status gantt chart')->

  with('request')->begin()->
    isParameter('module', 'idGantt')->
    isParameter('action', 'projectStatusGanttChartShow')->
    isParameter('project_id', '1')->
  end()->

  with('response')->begin()->
    checkElement('h2:contains("Project status gantt chart")')->
    checkElement('h3:contains("Legenda")')->
    checkElement('p:contains("Time for completing the project: 126.0 hours")')->
//    checkElement('p:contains("Estimated ending date: '.date('Y/m/d', strtotime("+ 14 days")).'")')->

    checkElement('p:contains("10 closed issues")')->
    checkElement('p:contains("5 new issues")')->
    checkElement('p:contains("7 invalid issues")')->

  end()

;
