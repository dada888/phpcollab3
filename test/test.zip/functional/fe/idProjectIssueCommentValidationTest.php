<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();


$browser->

  get('/')->
  click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->
  followRedirect()->

  click('My Projects')->
  click('Il mio terzo progetto')->
  click('View all issues')->
  click('#1')->

  click('Save', array('comment' => array(
    'body'           => ''
  )), array('method'=>'post'))->


responseContains('Comment cannot be empty')->

get('/')->
click('My Projects')->
click('Il mio terzo progetto')->
click('View all issues')->
click('#1')->

click('Save', array('comment' => array(
    'body'           => '1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901'
  )), array('method'=>'post'))->


responseContains('Comment too long. max 1000 characters')->


get('/')->
click('My Projects')->
click('Il mio terzo progetto')->
click('View all issues')->
click('#1')->

click('Save', array('comment' => array(
    'body'           => '1234567890',
    'issue_id'       => '100'
  )), array('method'=>'post'))->

responseContains('Invalid')->

get('/')->
click('My Projects')->
click('Il mio terzo progetto')->
click('View all issues')->
click('#1')->

click('Save', array('comment' => array(
    'body'           => '1234567890',
    'issue_id'       => '69'
  )), array('method'=>'post'))->

responseContains('Invalid')
;