<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();


$browser->
  get('/')->
  click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->

  followRedirect()->

  click('My Projects')->

  with('request')->begin()->
    isParameter('module', 'idProject')->
    isParameter('action', 'index')->
  end()->

  with('response')->begin()->
    checkElement('table.table tr th:contains("Name")')->
    checkElement('table.table tr th:contains("Description")')->

    checkElement('table.table tr td:contains("Il mio terzo progetto")')->
    checkElement('table.table tr td:contains("Il terzo progetto creato con il plugin idProjectManagmentPlugin")')->

    checkElement('table.table tr td:contains("Il mio secondo progetto")')->
    checkElement('table.table tr td:contains("Il secondo progetto creato con il plugin idProjectManagmentPlugin")')->

    checkElement('table.table tr th:contains("Actions")', false)->
    checkElement('table.table tr td a[href="/index.php/en/idProject/edit/3"]', false)->
    checkElement('table.table tr td a[href="/index.php/en/idProject/edit/2"]', false)->
  end()->

  click('Logout')->

  get('/')->
  click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))->

  followRedirect()->

  with('response')->begin()->
    checkElement('a[href="/index.php/en/idProject"]', 'All Projects')->
  end();
