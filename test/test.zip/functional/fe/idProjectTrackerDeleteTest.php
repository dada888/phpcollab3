<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser->

get('/')->

click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))->

  followRedirect()->

  click('Trackers')->

  with('response')->begin()->
    checkElement('td:contains("user story")')->
  end()->

  click('Delete')->

 followRedirect()->

 with('response')->begin()->
    checkElement('td:contains("user story")', false)->
    checkElement('td:contains("No Results")')->
  end()
;
