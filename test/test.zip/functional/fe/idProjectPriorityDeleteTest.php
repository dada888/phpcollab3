<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser->

get('/')->

click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))->

  followRedirect()->

  click('Priorities')->

  with('response')->begin()->
    checkElement('tr', 3)->
    checkElement('#block-tables table.table td:contains("normal")')->
    checkElement('#block-tables table.table td:contains("high")')->
  end()->

  click('Delete')->

  followRedirect()->

  with('response')->begin()->
    checkElement('tr', 2)->
    checkElement('#block-tables table.table td:contains("normal")', false)->
    checkElement('#block-tables table.table td:contains("high")')->
  end()
;
