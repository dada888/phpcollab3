<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();

$browser->

get('/')->

click('Login', array('signin' => array('username' => 'admin', 'password' => 'admin')))->

  followRedirect()->

  click('Permissions')->

  responseContains('42 results')->

  click('Delete', array(), array('position' => 2))->

 followRedirect()->

  responseContains('41 results')
;
