<?php

include(dirname(__FILE__).'/../../bootstrap/functional.php');

$browser = new idDoctrineTestFunctional(new sfBrowser());
$browser->inizilizeDatabase();


$browser->

  get('/')->
  click('Login', array('signin' => array('username' => 'puser', 'password' => 'puser')))->
  followRedirect()->

  click('My Projects')->

  click('Il mio quarto progetto')->

  with('response')->begin()->
    checkElement('a[href="/index.php/en/idProject/4/idMilestone/new"]', 'Create milestone')->
    checkElement('table.table tr td:contains("No milestone")')->
  end()->

  click('Create milestone')->

  with('request')->begin()->
    isParameter('module', 'idMilestone')->
    isParameter('action', 'new')->
  end();

  $browser->click('Save', array('milestone' => array(
    'title'           => 'first iteration',
    'description'     => 'first iteration of this project',
    'starting_date'   => array('day' => date('d', time()), 'month' => date('m', time()), 'year' => date('Y', time())),
    'ending_date'     => array('day' => date('d', strtotime('+1 month')), 'month' => date('m', strtotime('+1 month')), 'year' => date('Y', strtotime('+1 month')))
  )), array('methos'=>'post'))->

  followRedirect()->

  with('request')->begin()->
    isParameter('module', 'idProject')->
    isParameter('action', 'show')->
    isParameter('id', '4')->
  end();